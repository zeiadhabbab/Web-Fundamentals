"use strict"; // Enable strict mode for better error checking ECMAScript 5 feature
// Define moods
const moods = [
    {text: 'Happy', emoji: '😊', color: 'green'},
    {text: 'Sad', emoji: '😢', color: 'blue'},
    {text: 'Angry', emoji: '😠', color: 'red'},
    {text: 'Calm', emoji: '😌', color: 'lightblue'},
    {text: 'Focused', emoji: '🧠', color: 'lightblue'},
    {text: 'Chill', emoji: '😎', color: 'lightgreen'}
];




 