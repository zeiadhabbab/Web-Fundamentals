const clickSound = new Audio('c.mp3');

const navLinks = document.querySelectorAll('nav ul li a');
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        clickSound.currentTime = 0;
        clickSound.play();
    });
});

const sections = document.querySelectorAll('section');
const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = 1;
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, { threshold: 0.2 });

sections.forEach(section => {
    section.style.opacity = 0;
    section.style.transform = 'translateY(30px)';
    section.style.transition = 'all 0.6s ease-out';
    observer.observe(section);
});

const profileImg = document.querySelector('section#about img');
profileImg.addEventListener('mouseover', () => {
    profileImg.style.transform = 'scale(1.12) rotate(3deg)';
    profileImg.style.boxShadow = '0 20px 50px rgba(138, 43, 226, 0.6)';
});
profileImg.addEventListener('mouseout', () => {
    profileImg.style.transform = 'scale(1) rotate(0deg)';
    profileImg.style.boxShadow = '0 10px 30px rgba(75, 0, 130, 0.4)';
});
